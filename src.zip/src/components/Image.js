import React from 'react'
const imagStyle = {

    height:'600px' ,
    width:"100%"
}
export default function Image() {
    return (
     
            <img src='./images/1.jpg'  id='imagtag' style={imagStyle}></img>
       
    )
}
