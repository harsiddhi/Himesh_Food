import React from 'react'
import Titlabar from './Titlabar'

export default function About() {
    return (
        <div>
            <Titlabar title='About us'/>
        </div>
    )
}
